
import React, { useState } from 'react';
import { ReservationData } from '../types';

const ReservationForm: React.FC = () => {
  const [formData, setFormData] = useState<ReservationData>({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '19:00',
    guests: 2,
    specialRequests: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Reservation Submitted:", formData);
    setSubmitted(true);
    // In a real app, send to API
  };

  return (
    <section id="reservation" className="py-24 bg-stone-900 text-white">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto bg-stone-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
          <div className="md:w-2/5 relative h-64 md:h-auto">
            <img 
                src="https://picsum.photos/seed/reservation/600/800" 
                alt="Table Setup" 
                className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-amber-900/40 flex items-center justify-center">
              <div className="text-center p-6">
                <h4 className="text-3xl font-serif font-bold mb-4">Book Your Table</h4>
                <p className="text-stone-200">Secure your spot for an unforgettable evening in Ayodhya.</p>
              </div>
            </div>
          </div>
          
          <div className="md:w-3/5 p-8 md:p-12">
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-4xl mb-6 animate-bounce">✓</div>
                <h4 className="text-3xl font-bold mb-4">Reservation Confirmed!</h4>
                <p className="text-stone-400 mb-8">Namaste {formData.name}, we've received your request for {formData.date} at {formData.time}. A confirmation email has been sent.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="px-8 py-3 bg-amber-600 rounded-full hover:bg-amber-500 transition"
                >
                  Make Another Booking
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs uppercase tracking-widest mb-2 text-stone-400">Full Name</label>
                    <input 
                      required
                      type="text" 
                      className="w-full bg-stone-700 border-none rounded-lg p-3 text-white focus:ring-2 focus:ring-amber-500 outline-none"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-widest mb-2 text-stone-400">Phone Number</label>
                    <input 
                      required
                      type="tel" 
                      className="w-full bg-stone-700 border-none rounded-lg p-3 text-white focus:ring-2 focus:ring-amber-500 outline-none"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-xs uppercase tracking-widest mb-2 text-stone-400">Date</label>
                    <input 
                      required
                      type="date" 
                      className="w-full bg-stone-700 border-none rounded-lg p-3 text-white focus:ring-2 focus:ring-amber-500 outline-none"
                      value={formData.date}
                      onChange={(e) => setFormData({...formData, date: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-widest mb-2 text-stone-400">Time</label>
                    <select 
                      className="w-full bg-stone-700 border-none rounded-lg p-3 text-white focus:ring-2 focus:ring-amber-500 outline-none"
                      value={formData.time}
                      onChange={(e) => setFormData({...formData, time: e.target.value})}
                    >
                      <option>08:00 AM</option>
                      <option>10:00 AM</option>
                      <option>12:00 PM</option>
                      <option>02:00 PM</option>
                      <option>04:00 PM</option>
                      <option>06:00 PM</option>
                      <option>07:00 PM</option>
                      <option>08:00 PM</option>
                      <option>09:00 PM</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-widest mb-2 text-stone-400">Guests</label>
                    <input 
                      type="number" 
                      min="1" 
                      max="20"
                      className="w-full bg-stone-700 border-none rounded-lg p-3 text-white focus:ring-2 focus:ring-amber-500 outline-none"
                      value={formData.guests}
                      onChange={(e) => setFormData({...formData, guests: parseInt(e.target.value)})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-widest mb-2 text-stone-400">Special Requests</label>
                  <textarea 
                    className="w-full bg-stone-700 border-none rounded-lg p-3 text-white h-24 focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                    placeholder="Celebrations, dietary needs..."
                    value={formData.specialRequests}
                    onChange={(e) => setFormData({...formData, specialRequests: e.target.value})}
                  ></textarea>
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg transition transform hover:scale-[1.02]"
                >
                  Confirm Reservation
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReservationForm;
