
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 scale-105"
        style={{
          backgroundImage: 'url("https://picsum.photos/seed/cafe-hero/1920/1080")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'brightness(0.6)'
        }}
      />
      
      <div className="relative z-10 text-center text-white px-6 max-w-4xl">
        <h2 className="text-amber-400 text-xl md:text-2xl mb-4 font-serif italic">Welcome to Ayodhya's Finest</h2>
        <h1 className="text-5xl md:text-8xl font-bold mb-8 tracking-tight">Nauru's Cafe</h1>
        <p className="text-lg md:text-xl text-stone-200 mb-10 max-w-2xl mx-auto leading-relaxed">
          Where ancient heritage meets modern culinary artistry. Experience the soulful flavors of India in the heart of the holy city.
        </p>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <button 
            onClick={() => document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-md transition transform hover:scale-105 w-full md:w-auto"
          >
            Explore Menu
          </button>
          <button 
            onClick={() => document.getElementById('reservation')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-transparent border-2 border-white hover:bg-white hover:text-stone-900 text-white font-bold rounded-md transition w-full md:w-auto"
          >
            Reservations
          </button>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-1 h-12 rounded-full bg-white/30 flex justify-center">
          <div className="w-1 h-4 bg-white rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
