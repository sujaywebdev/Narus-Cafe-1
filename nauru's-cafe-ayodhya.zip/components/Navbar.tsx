
import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-6'
    }`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div 
          className="text-2xl font-serif font-bold cursor-pointer tracking-wider"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          NAURU'S <span className="text-amber-600">CAFE</span>
        </div>
        
        <div className="hidden md:flex space-x-8 text-sm font-semibold uppercase tracking-widest items-center">
          <button onClick={() => scrollToSection('about')} className="hover:text-amber-600 transition">About</button>
          <button onClick={() => scrollToSection('menu')} className="hover:text-amber-600 transition">Menu</button>
          <button onClick={() => scrollToSection('reservation')} className="hover:text-amber-600 transition">Reservations</button>
          <button onClick={() => scrollToSection('contact')} className="hover:text-amber-600 transition">Contact</button>
          <button 
            onClick={() => scrollToSection('reservation')}
            className="bg-stone-900 text-white px-6 py-2 rounded-full hover:bg-stone-800 transition shadow-lg"
          >
            Book Now
          </button>
        </div>

        <div className="md:hidden">
            {/* Mobile menu toggle would go here for a full implementation */}
            <span className="text-2xl">☰</span>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
