
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-stone-50 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2 relative">
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl">
              <img src="https://picsum.photos/seed/cafe-interior/800/1000" alt="Cafe Interior" className="w-full h-auto" />
            </div>
            <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-amber-100 rounded-full -z-10"></div>
            <div className="absolute -top-10 -left-10 w-32 h-32 bg-stone-200 rounded-full -z-10"></div>
            <div className="absolute bottom-10 -left-6 bg-white p-6 rounded-xl shadow-xl z-20 hidden md:block">
              <p className="text-amber-600 font-bold text-3xl">10+</p>
              <p className="text-stone-500 text-xs uppercase tracking-widest">Years of Tradition</p>
            </div>
          </div>
          
          <div className="lg:w-1/2">
            <h2 className="text-amber-600 font-serif italic mb-2 text-xl">The Story of Nauru's</h2>
            <h3 className="text-4xl md:text-5xl font-bold mb-6">A Legacy in the Holy City</h3>
            <p className="text-stone-600 mb-6 leading-relaxed">
              Nestled near the sacred paths of Ayodhya, Nauru's Cafe was born from a vision to create a space where pilgrims and travelers could find a modern sanctuary without losing touch with the city's timeless spirit.
            </p>
            <p className="text-stone-600 mb-8 leading-relaxed">
              Our kitchen honors local ingredients while embracing global techniques. From our saffron-infused brews that pay homage to the city's colors, to our fusion desserts, every dish tells a story of devotion and craftsmanship.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mb-10">
              <div className="p-4 bg-white rounded-lg shadow-sm border-l-4 border-amber-500">
                <p className="font-bold text-lg mb-1">Purity First</p>
                <p className="text-stone-500 text-sm">We use organic, locally sourced produce.</p>
              </div>
              <div className="p-4 bg-white rounded-lg shadow-sm border-l-4 border-amber-500">
                <p className="font-bold text-lg mb-1">Authentic Vibes</p>
                <p className="text-stone-500 text-sm">Traditional aesthetics with modern comfort.</p>
              </div>
            </div>

            <button className="text-amber-600 font-bold flex items-center gap-2 group">
              Read More About Our Heritage 
              <span className="group-hover:translate-x-2 transition-transform">→</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
