
import React from 'react';
import { CAFE_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer id="contact" className="bg-stone-100 py-20 border-t border-stone-200">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="md:col-span-1">
            <h4 className="text-2xl font-serif font-bold mb-6 tracking-wider">NAURU'S <span className="text-amber-600">CAFE</span></h4>
            <p className="text-stone-500 text-sm leading-relaxed mb-6">
              A celebration of Ayodhya's culinary heritage, reimagined for the contemporary soul.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full border border-stone-300 flex items-center justify-center hover:bg-amber-600 hover:border-amber-600 hover:text-white transition">IG</a>
              <a href="#" className="w-10 h-10 rounded-full border border-stone-300 flex items-center justify-center hover:bg-amber-600 hover:border-amber-600 hover:text-white transition">FB</a>
              <a href="#" className="w-10 h-10 rounded-full border border-stone-300 flex items-center justify-center hover:bg-amber-600 hover:border-amber-600 hover:text-white transition">X</a>
            </div>
          </div>

          <div>
            <h5 className="font-bold mb-6 uppercase tracking-widest text-sm">Quick Links</h5>
            <ul className="space-y-4 text-stone-500 text-sm">
              <li><button onClick={() => window.scrollTo(0,0)} className="hover:text-amber-600 transition">Home</button></li>
              <li><button onClick={() => document.getElementById('about')?.scrollIntoView({behavior:'smooth'})} className="hover:text-amber-600 transition">About Us</button></li>
              <li><button onClick={() => document.getElementById('menu')?.scrollIntoView({behavior:'smooth'})} className="hover:text-amber-600 transition">Our Menu</button></li>
              <li><button onClick={() => document.getElementById('reservation')?.scrollIntoView({behavior:'smooth'})} className="hover:text-amber-600 transition">Private Dining</button></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold mb-6 uppercase tracking-widest text-sm">Contact Us</h5>
            <ul className="space-y-4 text-stone-500 text-sm">
              <li className="flex items-start gap-3">
                <span className="text-amber-600">📍</span>
                {CAFE_INFO.location}
              </li>
              <li className="flex items-start gap-3">
                <span className="text-amber-600">📞</span>
                {CAFE_INFO.phone}
              </li>
              <li className="flex items-start gap-3">
                <span className="text-amber-600">✉️</span>
                {CAFE_INFO.email}
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold mb-6 uppercase tracking-widest text-sm">Opening Hours</h5>
            <ul className="space-y-4 text-stone-500 text-sm">
              <li>
                <span className="block text-stone-900 font-semibold">Every Day</span>
                08:00 AM - 11:00 PM
              </li>
              <li>
                <span className="block text-stone-900 font-semibold">Holidays</span>
                Timings may vary based on city events.
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-stone-200 flex flex-col md:flex-row justify-between items-center text-xs text-stone-400 gap-4">
          <p>© {new Date().getFullYear()} Nauru's Cafe Ayodhya. All rights reserved.</p>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-amber-600 transition">Privacy Policy</a>
            <a href="#" className="hover:text-amber-600 transition">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
