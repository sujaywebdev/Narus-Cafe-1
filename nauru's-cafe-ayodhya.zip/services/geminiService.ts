
import { GoogleGenAI, Type } from "@google/genai";
import { MENU_ITEMS, CAFE_INFO } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_PROMPT = `
You are the AI Concierge for Nauru's Cafe in Ayodhya. 
Your goal is to provide excellent customer service, recommend items from our menu, and answer questions about the cafe.
Cafe Info:
- Location: ${CAFE_INFO.location}
- Hours: ${CAFE_INFO.hours}
- Specialties: ${MENU_ITEMS.map(i => i.name).join(', ')}

Be polite, warm, and professional. Mention the spiritual and cultural heritage of Ayodhya when appropriate.
If someone wants to book a table, guide them to use our reservation form on the website.
Keep responses concise but welcoming.
`;

export const getChatResponse = async (userMessage: string, history: { role: 'user' | 'model', text: string }[]) => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_PROMPT,
      },
    });

    // Simple chat doesn't support full history in this SDK wrapper easily without manual mapping,
    // so we'll use a simplified version for this demo.
    const response = await chat.sendMessage({ message: userMessage });
    return response.text || "I'm sorry, I'm having trouble connecting to my brain right now. Please try again!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Something went wrong. I'm taking a quick tea break, please message me in a moment!";
  }
};
