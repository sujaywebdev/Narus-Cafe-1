
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Appetizers' | 'Main Course' | 'Beverages' | 'Desserts' | 'Specialty';
  image: string;
  isVegetarian: boolean;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface ReservationData {
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  specialRequests: string;
}
