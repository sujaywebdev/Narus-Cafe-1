
import React, { Suspense } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Menu from './components/Menu';
import ReservationForm from './components/ReservationForm';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  return (
    <div className="relative min-h-screen bg-stone-50 selection:bg-amber-100 selection:text-amber-900">
      <Navbar />
      
      <main>
        <Hero />
        <About />
        
        {/* Gallery Preview Section */}
        <section className="py-12 bg-white flex overflow-hidden whitespace-nowrap">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="inline-block w-72 h-48 md:w-96 md:h-64 flex-shrink-0 mx-2 rounded-xl overflow-hidden hover:scale-105 transition-transform duration-500">
              <img src={`https://picsum.photos/seed/gallery-${i}/800/600`} className="w-full h-full object-cover" alt="Gallery" />
            </div>
          ))}
        </section>

        <Menu />
        
        {/* Testimonial Section */}
        <section className="py-24 bg-amber-50 text-center">
            <div className="container mx-auto px-6 max-w-4xl">
                <span className="text-4xl text-amber-300 block mb-6">"</span>
                <p className="text-2xl md:text-3xl font-serif italic text-stone-800 mb-8">
                    "A serene oasis in Ayodhya. The saffron latte is a revelation, and the atmosphere perfectly captures the sacred yet sophisticated vibe of the city."
                </p>
                <div className="w-12 h-12 rounded-full overflow-hidden mx-auto mb-4">
                    <img src="https://picsum.photos/seed/avatar/100/100" alt="Avatar" />
                </div>
                <h5 className="font-bold uppercase tracking-widest text-sm">Aditi Sharma</h5>
                <p className="text-stone-500 text-xs">Frequent Traveler & Food Critic</p>
            </div>
        </section>

        <ReservationForm />
      </main>

      <Footer />
      <Chatbot />

      {/* Subtle background decorative elements */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-10 opacity-5">
        <div className="absolute top-1/4 -left-24 w-96 h-96 bg-amber-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 -right-24 w-96 h-96 bg-stone-400 rounded-full blur-3xl"></div>
      </div>
    </div>
  );
};

export default App;
