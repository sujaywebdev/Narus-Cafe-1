
import { MenuItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  {
    id: '1',
    name: 'Saffron Infused Paneer Tikka',
    description: 'Fresh cottage cheese marinated in rare saffron and Awadhi spices, grilled to perfection.',
    price: 450,
    category: 'Appetizers',
    image: 'https://picsum.photos/seed/paneer/600/400',
    isVegetarian: true,
  },
  {
    id: '2',
    name: 'Temple City Platter',
    description: 'A curated selection of Ayodhya’s favorite street snacks served with house-made mint chutney.',
    price: 550,
    category: 'Appetizers',
    image: 'https://picsum.photos/seed/platter/600/400',
    isVegetarian: true,
  },
  {
    id: '3',
    name: 'Truffle Mushroom Risotto',
    description: 'Creamy Arborio rice with wild forest mushrooms and a hint of white truffle oil.',
    price: 680,
    category: 'Main Course',
    image: 'https://picsum.photos/seed/risotto/600/400',
    isVegetarian: true,
  },
  {
    id: '4',
    name: 'Nauru’s Signature Dal',
    description: 'Slow-cooked black lentils simmered overnight with cream and artisanal butter.',
    price: 420,
    category: 'Main Course',
    image: 'https://picsum.photos/seed/dal/600/400',
    isVegetarian: true,
  },
  {
    id: '5',
    name: 'Rose & Cardamom Latte',
    description: 'Fragrant espresso with steamed milk, infused with organic rose petals and green cardamom.',
    price: 280,
    category: 'Beverages',
    image: 'https://picsum.photos/seed/latte/600/400',
    isVegetarian: true,
  },
  {
    id: '6',
    name: 'Baked Rabri Cheesecake',
    description: 'A fusion of classic New York cheesecake and traditional Indian Rabri.',
    price: 350,
    category: 'Desserts',
    image: 'https://picsum.photos/seed/cheesecake/600/400',
    isVegetarian: true,
  }
];

export const CAFE_INFO = {
  name: "Nauru's Cafe",
  location: "Near Ram Janmabhoomi Path, Ayodhya, Uttar Pradesh",
  hours: "Monday - Sunday: 8:00 AM - 11:00 PM",
  phone: "+91 8888 7777 66",
  email: "hello@nauruscafe.com"
};
